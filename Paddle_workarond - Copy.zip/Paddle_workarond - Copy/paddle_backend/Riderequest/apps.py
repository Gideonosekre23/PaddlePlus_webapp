from django.apps import AppConfig


class RiderequestConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Riderequest'
