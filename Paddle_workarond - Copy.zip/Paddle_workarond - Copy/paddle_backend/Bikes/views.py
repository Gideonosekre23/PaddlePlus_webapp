from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from Owner.models import OwnerProfile  
from Owner.serializers import BikesSerializer
from .models import Bikes, BikeHardware
from geopy.distance import geodesic
from .pricing import calculate_price
from django.utils import timezone
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync

@api_view(['POST'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def activate_bike(request, bike_id):
    bike = get_object_or_404(Bikes, pk=bike_id, owner=request.user.owner_profile)
    scanned_serial = request.data.get('serial_number')
    
    if bike.activate_with_hardware(scanned_serial):
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            f'notifications_{request.user.id}',
            {
                'type': 'send_notification',
                'title': 'Bike Activated',
                'message': f'Bike {bike.bike_name} has been activated successfully',
                'data': {
                    'bike_id': bike.id,
                    'hardware_status': bike.get_hardware_status()
                }
            }
        )
        return Response({
            'message': 'Bike activated successfully',
            'hardware_status': bike.get_hardware_status()
        })
    return Response({'error': 'Invalid or already assigned hardware'}, status=400)

@api_view(['POST'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def get_bike_unlock_code(request, bike_id):
    bike = get_object_or_404(Bikes, pk=bike_id)
    if not bike.is_active or not bike.is_available or bike.bike_status != 'available':
        return Response({'error': 'Bike is not available'}, status=400)
    
    if bike.verify_unlock_code(request.data.get('code')):
        channel_layer = get_channel_layer()
        for user_id in [request.user.id, bike.owner.user.id]:
            async_to_sync(channel_layer.group_send)(
                f'notifications_{user_id}',
                {
                    'type': 'send_notification',
                    'title': 'Bike Unlocked',
                    'message': f'Bike {bike.bike_name} has been unlocked',
                    'data': {
                        'bike_id': bike.id,
                        'hardware_status': bike.get_hardware_status()
                    }
                }
            )
        return Response({
            'message': 'Bike unlocked successfully',
            'hardware_status': bike.get_hardware_status()
        })
    return Response({'error': 'Invalid unlock code'}, status=400)

@api_view(['POST'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def lock_bike(request, bike_id):
    bike = get_object_or_404(Bikes, pk=bike_id)
    if bike.lock_bike():
        channel_layer = get_channel_layer()
        for user_id in [request.user.id, bike.owner.user.id]:
            async_to_sync(channel_layer.group_send)(
                f'notifications_{user_id}',
                {
                    'type': 'send_notification',
                    'title': 'Bike Locked',
                    'message': f'Bike {bike.bike_name} has been locked',
                    'data': {
                        'bike_id': bike.id,
                        'hardware_status': bike.get_hardware_status()
                    }
                }
            )
        return Response({
            'message': 'Bike locked successfully',
            'hardware_status': bike.get_hardware_status()
        })
    return Response({'error': 'Could not lock bike'}, status=400)

@api_view(['POST'])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def toggle_bike_availability(request, bike_id):
    bike = get_object_or_404(Bikes, pk=bike_id, owner=request.user.owner_profile)
    
    if not bike.is_active:
        return Response({'error': 'Bike must be activated first'}, status=400)
        
    bike.is_available = not bike.is_available
    bike.bike_status = 'available' if bike.is_available else 'disabled'
    bike.save()
    
    channel_layer = get_channel_layer()
    async_to_sync(channel_layer.group_send)(
        f'notifications_{request.user.id}',
        {
            'type': 'send_notification',
            'title': 'Bike Availability Updated',
            'message': f'Bike {bike.bike_name} is now {"available" if bike.is_available else "hidden"}',
            'data': {
                'bike_id': bike.id,
                'is_available': bike.is_available,
                'bike_status': bike.bike_status
            }
        }
    )
    
    return Response({
        'message': f'Bike is now {"available" if bike.is_available else "hidden"} on the map',
        'is_available': bike.is_available,
        'bike_status': bike.bike_status
    })
